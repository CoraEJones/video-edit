from .effect_meta import EffectEnum
from .effect_meta import EffectMeta, EffectParam

class ToneEffectType(EffectEnum):
    """剪映自带的音频“音色”效果类型

    当前主库按最小草稿结构导出此类效果，实测在剪映5.9与10.8中可生效。
    """

    # 免费
    圣诞精灵    = EffectMeta("圣诞精灵", False, "7310059412062736946", "33214695", "8dd8889045e6c065177df791ddb3dfb8", [])
    圣诞老人    = EffectMeta("圣诞老人", False, "7310059178133819930", "33214489", "8dd8889045e6c065177df791ddb3dfb8", [])
    广告男声    = EffectMeta("广告男声", False, "7328088579811316263", "42060748", "f554735f65a98cc4da17a1c53ef6a886", [])
    港普男声    = EffectMeta("港普男声", False, "7328087687548637732", "42060743", "f554735f65a98cc4da17a1c53ef6a886", [])
    老婆婆      = EffectMeta("老婆婆", False, "7328089253114548799", "42060746", "f554735f65a98cc4da17a1c53ef6a886", [])
    解说小帅    = EffectMeta("解说小帅", False, "7332473259369173540", "44254166", "f554735f65a98cc4da17a1c53ef6a886", [])
    大叔        = EffectMeta("大叔", False, "7020344898033291790", "2672760", "2509bbd71e127b04a29f52a54e82c53c", [
                                    EffectParam("音调", 0.834, 0.000, 1.000),
                                    EffectParam("音色", 1.000, 0.000, 1.000)])
    """参数:
        - 音调: 默认0.83, 0.00 ~ 1.00
        - 音色: 默认1.00, 0.00 ~ 1.00
    """
    女生        = EffectMeta("女生", False, "7020345715901600270", "2672757", "0ce1aade5958506c97bffea150772b6e", [
                                    EffectParam("音调", 0.834, 0.000, 1.000),
                                    EffectParam("音色", 0.334, 0.000, 1.000)])
    """参数:
        - 音调: 默认0.83, 0.00 ~ 1.00
        - 音色: 默认0.33, 0.00 ~ 1.00
    """
    怪物        = EffectMeta("怪物", False, "7020344978794615327", "2672759", "2130ffa21e5980196e014ec0baade179", [
                                    EffectParam("音调", 0.650, 0.000, 1.000),
                                    EffectParam("音色", 0.780, 0.000, 1.000)])
    """参数:
        - 音调: 默认0.65, 0.00 ~ 1.00
        - 音色: 默认0.78, 0.00 ~ 1.00
    """
    机器人      = EffectMeta("机器人", False, "7018011705414259213", "2672750", "4b87db25aecd2f6f71927930110c4a1e", [
                                    EffectParam("强弱", 1.000, 0.000, 1.000)])
    """参数:
        - 强弱: 默认1.00, 0.00 ~ 1.00
    """
    男生        = EffectMeta("男生", False, "7020345085233467917", "2672758", "ffd7a609207fd849efc9f63bf31697b1", [
                                    EffectParam("音调", 0.375, 0.000, 1.000),
                                    EffectParam("音色", 0.250, 0.000, 1.000)])
    """参数:
        - 音调: 默认0.38, 0.00 ~ 1.00
        - 音色: 默认0.25, 0.00 ~ 1.00
    """
    花栗鼠      = EffectMeta("花栗鼠", False, "7018011553081332231", "2672752", "e30b1922b8300423f21f9f84eff41ced", [
                                    EffectParam("音调", 0.500, 0.000, 1.000),
                                    EffectParam("音色", 0.500, 0.000, 1.000)])
    """参数:
        - 音调: 默认0.50, 0.00 ~ 1.00
        - 音色: 默认0.50, 0.00 ~ 1.00
    """
    萝莉        = EffectMeta("萝莉", False, "7020345789599715848", "2672756", "00b7ed2ccfe4d6076f78c8d751347a53", [
                                    EffectParam("音调", 0.750, 0.000, 1.000),
                                    EffectParam("音色", 0.600, 0.000, 1.000)])
    """参数:
        - 音调: 默认0.75, 0.00 ~ 1.00
        - 音色: 默认0.60, 0.00 ~ 1.00
    """


    # 付费
    台湾小哥    = EffectMeta("台湾小哥", True, "7255565276819755576", "18149602", "8dd8889045e6c065177df791ddb3dfb8", [
                                    EffectParam.extra("speaker_id", "zh_male_taiwan"),
                                    EffectParam.extra("vc_type", "speech"),
                                    EffectParam.extra("source_platform", 1),
                                    EffectParam.extra("third_resource_id", "7255565276819755576")])
    热情甜妹    = EffectMeta("热情甜妹", True, "7582867547742145843", "7582867547742145843", "", [
                                    EffectParam.extra("speaker_id", "VC_zh_female_zhanglaoban"),
                                    EffectParam.extra("vc_type", "speech"),
                                    EffectParam.extra("source_platform", 1),
                                    EffectParam.extra("third_resource_id", "0")])
    曼波讲故事  = EffectMeta("曼波讲故事", True, "7517562443405544740", "7517562443405544740", "f554735f65a98cc4da17a1c53ef6a886", [
                                    EffectParam.extra("speaker_id", "VC_zh_male_manbo"),
                                    EffectParam.extra("vc_type", "speech"),
                                    EffectParam.extra("source_platform", 1),
                                    EffectParam.extra("third_resource_id", "0")])
    TVB女声     = EffectMeta("TVB女声", True, "7260024060417937978", "19186454", "8dd8889045e6c065177df791ddb3dfb8", [
                                    EffectParam.extra("speaker_id", "zh_female_tvb"),
                                    EffectParam.extra("vc_type", "speech"),
                                    EffectParam.extra("source_platform", 1),
                                    EffectParam.extra("third_resource_id", "7260024060417937978")])
    娱乐扒妹II  = EffectMeta("娱乐扒妹II", True, "7517556872564477195", "7517556872564477195", "f554735f65a98cc4da17a1c53ef6a886", [
                                    EffectParam.extra("speaker_id", "VC_zh_female_bameiII"),
                                    EffectParam.extra("vc_type", "speech"),
                                    EffectParam.extra("source_platform", 1),
                                    EffectParam.extra("third_resource_id", "0")])
    台湾女生    = EffectMeta("台湾女生", True, "7550588076523785518", "7550588076523785518", "f554735f65a98cc4da17a1c53ef6a886", [
                                    EffectParam.extra("speaker_id", "VC_zh_female_taiwannv"),
                                    EffectParam.extra("vc_type", "speech"),
                                    EffectParam.extra("source_platform", 1),
                                    EffectParam.extra("third_resource_id", "0")])
    直率英子    = EffectMeta("直率英子", True, "7369177370873303587", "7369177370873303587", "f554735f65a98cc4da17a1c53ef6a886", [
                                    EffectParam.extra("speaker_id", "zh_female_naying"),
                                    EffectParam.extra("vc_type", "speech"),
                                    EffectParam.extra("source_platform", 1),
                                    EffectParam.extra("third_resource_id", "7369177370873303587")])
    东厂公公    = EffectMeta("东厂公公", True, "7328092524612948491", "42060742", "f554735f65a98cc4da17a1c53ef6a886", [])
    云龙哥      = EffectMeta("云龙哥", True, "7376558114830553612", "68856989", "f554735f65a98cc4da17a1c53ef6a886", [])
    侠客        = EffectMeta("侠客", True, "7328089134331859468", "42060738", "f554735f65a98cc4da17a1c53ef6a886", [])
    做作夹子音  = EffectMeta("做作夹子音", True, "7367676929496846911", "63231108", "f554735f65a98cc4da17a1c53ef6a886", [])
    八戒        = EffectMeta("八戒", True, "7265891792766112314", "20427371", "8dd8889045e6c065177df791ddb3dfb8", [])
    军事解说    = EffectMeta("军事解说", True, "7328092289480266252", "42060734", "f554735f65a98cc4da17a1c53ef6a886", [])
    动漫小新    = EffectMeta("动漫小新", True, "7360901047662940708", "58979441", "f554735f65a98cc4da17a1c53ef6a886", [])
    动漫海绵    = EffectMeta("动漫海绵", True, "7367676859883983379", "63231109", "f554735f65a98cc4da17a1c53ef6a886", [])
    咆哮哥      = EffectMeta("咆哮哥", True, "7332473122605503039", "44254278", "f554735f65a98cc4da17a1c53ef6a886", [])
    商务殷语    = EffectMeta("商务殷语", True, "7328085477267870249", "42060747", "f554735f65a98cc4da17a1c53ef6a886", [])
    四郎        = EffectMeta("四郎", True, "7250403044414722621", "16627073", "8dd8889045e6c065177df791ddb3dfb8", [])
    太白        = EffectMeta("太白", True, "7328091247308968484", "42060736", "f554735f65a98cc4da17a1c53ef6a886", [])
    如来佛祖    = EffectMeta("如来佛祖", True, "7376558174049931830", "68856990", "f554735f65a98cc4da17a1c53ef6a886", [])
    姜饼人      = EffectMeta("姜饼人", True, "7310059267384414747", "33214539", "8dd8889045e6c065177df791ddb3dfb8", [])
    容嬷嬷      = EffectMeta("容嬷嬷", True, "7332472945366798860", "44254320", "f554735f65a98cc4da17a1c53ef6a886", [])
    小孩        = EffectMeta("小孩", True, "7262648951948448315", "19716244", "8dd8889045e6c065177df791ddb3dfb8", [])
    强势妹      = EffectMeta("强势妹", True, "7328091624427229759", "42060740", "f554735f65a98cc4da17a1c53ef6a886", [])
    快板        = EffectMeta("快板", True, "7328088454183522827", "42060741", "f554735f65a98cc4da17a1c53ef6a886", [])
    恐怖电影    = EffectMeta("恐怖电影", True, "7325710953247412787", "40932465", "f554735f65a98cc4da17a1c53ef6a886", [])
    悬疑解说    = EffectMeta("悬疑解说", True, "7325711304390349362", "40932811", "f554735f65a98cc4da17a1c53ef6a886", [])
    懒小羊      = EffectMeta("懒小羊", True, "7332473035116515859", "44254304", "f554735f65a98cc4da17a1c53ef6a886", [])
    搞笑解说    = EffectMeta("搞笑解说", True, "7262648842238038584", "19716150", "8dd8889045e6c065177df791ddb3dfb8", [])
    文艺女声    = EffectMeta("文艺女声", True, "7379565719991620132", "70562787", "f554735f65a98cc4da17a1c53ef6a886", [])
    樱桃丸子    = EffectMeta("樱桃丸子", True, "7325709643332719113", "40931609", "f554735f65a98cc4da17a1c53ef6a886", [])
    樱花小哥    = EffectMeta("樱花小哥", True, "7328091741678998055", "42060735", "f554735f65a98cc4da17a1c53ef6a886", [])
    武则天      = EffectMeta("武则天", True, "7328088300474864167", "42060744", "f554735f65a98cc4da17a1c53ef6a886", [])
    沉稳解说    = EffectMeta("沉稳解说", True, "7367676791164506636", "63231110", "f554735f65a98cc4da17a1c53ef6a886", [])
    温柔姐姐    = EffectMeta("温柔姐姐", True, "7379565769190806079", "70562785", "f554735f65a98cc4da17a1c53ef6a886", [])
    熊二        = EffectMeta("熊二", True, "7250403222798471740", "16627311", "8dd8889045e6c065177df791ddb3dfb8", [
                                    EffectParam.extra("speaker_id", "zh_male_xionger"),
                                    EffectParam.extra("vc_type", "speech"),
                                    EffectParam.extra("source_platform", 1),
                                    EffectParam.extra("third_resource_id", "7250403222798471740")])
    猴哥        = EffectMeta("猴哥", True, "7532395986618946102", "14477015", "4f6a1fbc0000e178c724d355efea1d9f", [
                                    EffectParam.extra("speaker_id", "zh_male_sunwukong"),
                                    EffectParam.extra("vc_type", "speech"),
                                    EffectParam.extra("source_platform", 1),
                                    EffectParam.extra("third_resource_id", "7532395986618946102")])
    甜美悦悦    = EffectMeta("甜美悦悦", True, "7325710673978069530", "40932253", "f554735f65a98cc4da17a1c53ef6a886", [])
    生活小妙招  = EffectMeta("生活小妙招", True, "7328092409525441065", "42060737", "f554735f65a98cc4da17a1c53ef6a886", [])
    电竞解说    = EffectMeta("电竞解说", True, "7325711893551649330", "40933559", "f554735f65a98cc4da17a1c53ef6a886", [])
    电视广告    = EffectMeta("电视广告", True, "7360901109667336743", "58979440", "f554735f65a98cc4da17a1c53ef6a886", [])
    紫薇        = EffectMeta("紫薇", True, "7281175506391667257", "23475307", "8dd8889045e6c065177df791ddb3dfb8", [])
    舌尖解说    = EffectMeta("舌尖解说", True, "7328091500753982015", "42060739", "f554735f65a98cc4da17a1c53ef6a886", [])
    蜡笔小妮    = EffectMeta("蜡笔小妮", True, "7379565670398169619", "70562786", "f554735f65a98cc4da17a1c53ef6a886", [])
    语音助手    = EffectMeta("语音助手", True, "7325710335455793714", "40931973", "f554735f65a98cc4da17a1c53ef6a886", [])
    那姐        = EffectMeta("那姐", True, "7369177370873303587", "64206631", "f554735f65a98cc4da17a1c53ef6a886", [])
    锤子哥      = EffectMeta("锤子哥", True, "7328091348098093580", "42060745", "f554735f65a98cc4da17a1c53ef6a886", [])
    顾姐        = EffectMeta("顾姐", True, "7250403134923608631", "16627197", "8dd8889045e6c065177df791ddb3dfb8", [])
    黛玉        = EffectMeta("黛玉", True, "7255565592093004343", "18149634", "8dd8889045e6c065177df791ddb3dfb8", [])
